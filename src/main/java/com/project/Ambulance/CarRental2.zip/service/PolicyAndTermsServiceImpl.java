package com.project.CarRental2.service;

public class PolicyAndTermsServiceImpl implements PolicyAndTermService {

}
