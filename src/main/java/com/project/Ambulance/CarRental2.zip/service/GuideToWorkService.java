package com.project.CarRental2.service;

public interface GuideToWorkService {

}
