package com.project.CarRental2.service;

public class GuideToWorkServiceImpl  implements GuideToWorkService{

}
